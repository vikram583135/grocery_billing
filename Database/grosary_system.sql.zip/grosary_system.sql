-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 22, 2017 at 08:48 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `grosary_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `billdetails`
--

CREATE TABLE `billdetails` (
  `bill_id` int(11) default NULL,
  `bill_master_id` int(11) default NULL,
  `pro_id` int(11) default NULL,
  `quantity` int(11) default NULL,
  `rate` int(11) default NULL,
  `discount` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billdetails`
--

INSERT INTO `billdetails` (`bill_id`, `bill_master_id`, `pro_id`, `quantity`, `rate`, `discount`) VALUES
(8, 4, 15, 2, 1000, 12),
(9, 4, 17, 2, 2000, 0),
(10, 4, 17, 10, 30, 25),
(11, 4, 16, 9, 89, 0),
(13, 5, 16, 1, 20, 0),
(14, 6, 18, 2, 100, 0),
(15, 6, 17, 10, 20, 0),
(4, 4, 16, 10, 10, 30),
(4, 4, 16, 10, 10, 30),
(16, 7, 15, 2, 200, 30),
(17, 7, 15, 1, 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `billmaster`
--

CREATE TABLE `billmaster` (
  `bill_master_id` int(11) default NULL,
  `bill_date` varchar(255) default NULL,
  `cust_id` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billmaster`
--

INSERT INTO `billmaster` (`bill_master_id`, `bill_date`, `cust_id`) VALUES
(3, '2009-9-9', 300),
(4, '6-3-2014', 16),
(5, '6-3-2014', 19),
(6, '6-3-2014', 23),
(4, '8-3-2014', 16),
(7, '8-3-2014', 23);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(11) default NULL,
  `cust_name` varchar(255) default NULL,
  `cust_phone` varchar(255) default NULL,
  `cust_email` varchar(255) default NULL,
  `date_become_cust` varchar(255) default NULL,
  `cust_city` varchar(255) default NULL,
  `pincode` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `cust_name`, `cust_phone`, `cust_email`, `date_become_cust`, `cust_city`, `pincode`) VALUES
(14, 'anu', '8745679098', 'anu@gmail.com', '2002-3-4', 'karnatak', '591432'),
(16, 'ashhhh', '567543228', 'ash@gmail.com', '2002-3-4', 'belgaum', '7654328976'),
(20, 'priya', '5454645654', 'pria@gmail.com', '2012-5-9', 'mumbai', '987678'),
(19, 'ash', '7878986756', 'ash@gmail.com', '2012-5-9', 'belgaum', '785423'),
(21, 'geeta', '9343893029', 'geeta@gmail.com', '2000-1-1', 'gudaganatti', '675432'),
(23, 'santosh', '9886631818', 'sneha@gmail.com', '1986-04-02', 'dwwd', '12345'),
(24, 'seema', '7654332547', 'seema@gmail.com', '2012-5-9', 'goa', '987654');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(11) default NULL,
  `emp_name` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `emp_phone` varchar(255) default NULL,
  `gender` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_name`, `address`, `emp_phone`, `gender`) VALUES
(13, 'anu', 'hattargi', '8792783416', 'female'),
(14, 'nandu', 'hattargiiii', '8792783416', 'female'),
(17, 'basuuuuu', 'goa', '6567798765', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  `hint_qst` varchar(255) default NULL,
  `hint_ans` varchar(255) default NULL,
  `status` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`, `hint_qst`, `hint_ans`, `status`) VALUES
('admin', '669', 'admin', 'What is your favourite color?', 'Pink', 'active'),
('customer', '3416', 'customer', 'What is your favourite color?', 'Pink', 'active'),
('suppliers', '143', 'suppliers', 'What is your favourite color?', 'Pink', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `ord_id` int(11) default NULL,
  `ord_mast_id` int(11) default NULL,
  `pro_id` int(11) default NULL,
  `quantity` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`ord_id`, `ord_mast_id`, `pro_id`, `quantity`) VALUES
(1, 12, NULL, 5),
(2, 13, 17, 2),
(3, 14, 15, 1),
(4, 15, 15, 2),
(5, 15, 15, 23);

-- --------------------------------------------------------

--
-- Table structure for table `ordermaster`
--

CREATE TABLE `ordermaster` (
  `ord_mast_id` int(11) default NULL,
  `ord_date` varchar(255) default NULL,
  `sup_id` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordermaster`
--

INSERT INTO `ordermaster` (`ord_mast_id`, `ord_date`, `sup_id`) VALUES
(5, '1991', 1),
(6, '2000-8-1', 1),
(7, '2000-8-1', 1),
(8, '2000', 1),
(12, '5-3-2014', 14),
(13, '5-3-2014', 14),
(14, '5-3-2014', 14),
(15, '5-3-2014', 14);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pro_id` int(11) default NULL,
  `pro_name` varchar(255) default NULL,
  `pro_price_purchase` int(11) default NULL,
  `pro_price_sales` int(11) default NULL,
  `current_stock` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pro_id`, `pro_name`, `pro_price_purchase`, `pro_price_sales`, `current_stock`) VALUES
(15, 'laptop', 30000, 40000, 6),
(16, 'bags', 300, 400, 1),
(17, 'nirma', 2, 3, 555),
(18, 'Sugar', 80, 100, 100);

-- --------------------------------------------------------

--
-- Table structure for table `purchasedetails`
--

CREATE TABLE `purchasedetails` (
  `pur_id` int(11) default NULL,
  `pur_master_id` int(11) default NULL,
  `pro_id` int(11) default NULL,
  `quantity` int(11) default NULL,
  `rate` int(11) default NULL,
  `discount` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchasedetails`
--

INSERT INTO `purchasedetails` (`pur_id`, `pur_master_id`, `pro_id`, `quantity`, `rate`, `discount`) VALUES
(3, NULL, 3, 33, 27, NULL),
(4, 4, 15, 3, 100, 10),
(5, 4, 17, 2, 39, 2);

-- --------------------------------------------------------

--
-- Table structure for table `purchasemaster`
--

CREATE TABLE `purchasemaster` (
  `pur_master_id` int(11) default NULL,
  `pur_date` varchar(255) default NULL,
  `sup_id` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchasemaster`
--

INSERT INTO `purchasemaster` (`pur_master_id`, `pur_date`, `sup_id`) VALUES
(2, '2000-3-2', 2),
(3, '2011-8-17', 3),
(4, '8-3-2014', 16),
(5, '8-3-2014', 14),
(6, '22-10-2017', 14);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `sup_id` int(11) default NULL,
  `sup_name` varchar(255) default NULL,
  `sup_phone` varchar(255) default NULL,
  `sup_email` varchar(255) default NULL,
  `sup_address` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`sup_id`, `sup_name`, `sup_phone`, `sup_email`, `sup_address`) VALUES
(14, 'purni', '6578543219', 'aniiiii@gmail.com', 'hattargi'),
(16, 'geeta', '7654345679', 'geet@gmail.com', 'Gudagnatti'),
(17, 'raghu', '56787909887', 'raghu@gmail.com', 'Gudagnatti'),
(18, 'aniiiii', '8654367788', 'aniiiii@gmail.com', 'hattargi');
